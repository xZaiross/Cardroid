package models

class WikiQueryData {
    val pages: ArrayList<WikiPage> = ArrayList()
}