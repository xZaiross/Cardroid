package models

class WikiResult {
    val query: WikiQueryData? = null
}