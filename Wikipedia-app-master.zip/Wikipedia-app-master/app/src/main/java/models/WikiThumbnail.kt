package models

class WikiThumbnail {
    val source: String? = null
    val width: Int = 0
    val height: Int = 0
}